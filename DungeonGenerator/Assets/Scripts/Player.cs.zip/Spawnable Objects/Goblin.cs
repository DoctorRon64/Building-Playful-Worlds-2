﻿using UnityEngine;
public class Goblin : Enemy
{

}
