﻿using UnityEngine;
public class Zombie : Enemy
{

}
