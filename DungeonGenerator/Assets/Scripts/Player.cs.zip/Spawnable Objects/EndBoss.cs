using UnityEngine;

public class EndBoss : Enemy
{

}
